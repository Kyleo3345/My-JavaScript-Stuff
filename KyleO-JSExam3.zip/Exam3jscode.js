$(document).ready(function(){
  $("#toggle").click(function(){
    $("#panel").fadeToggle(500);
  });
});